from functionsP.corr import *
from functionsP.discretizacion import*
from functionsP.filtrado import*
from functionsP.graficos import*
from functionsP.metricas import*
from functionsP.normest import*